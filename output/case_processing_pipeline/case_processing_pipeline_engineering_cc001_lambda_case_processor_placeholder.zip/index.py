import boto3
import pandas as pd
from io import StringIO
from datetime import datetime

s3_client = boto3.client('s3')

def handler(event, context):
    print('Hello World')
    
    # Get bucket and key from event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Read CSV from S3
    response = s3_client.get_object(Bucket=bucket, Key=key)
    csv_content = response['Body'].read().decode('utf-8')
    
    # Load into pandas dataframe
    df = pd.read_csv(StringIO(csv_content))
    
    # Add createdate column with today's date
    df['createdate'] = datetime.now().strftime('%Y-%m-%d')
    
    # Write to target bucket
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    
    target_key = key.replace('case/', 'case_stg/')
    s3_client.put_object(
        Bucket='tgt',
        Key=target_key,
        Body=csv_buffer.getvalue()
    )
    
    return {'statusCode': 200, 'message': 'File processed successfully'}
