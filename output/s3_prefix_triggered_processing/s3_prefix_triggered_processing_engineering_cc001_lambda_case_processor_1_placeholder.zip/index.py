import json
import boto3
import os

s3 = boto3.client('s3')

def handler(event, context):
    target_bucket = os.environ.get('TARGET_BUCKET')
    
    for record in event['Records']:
        source_bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        copy_source = {'Bucket': source_bucket, 'Key': key}
        s3.copy_object(CopySource=copy_source, Bucket=target_bucket, Key=key)
        
    return {'statusCode': 200, 'body': json.dumps('Processing complete')}
