import json
import boto3
import os
from urllib.parse import unquote_plus

s3 = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET_BUCKET']
    minilake_bucket = os.environ['MINILAKE_BUCKET']
    
    prefixes = ['collision/', 'party/', 'victim/', 'case/']
    
    for prefix in prefixes:
        response = s3.list_objects_v2(Bucket=staging_bucket, Prefix=prefix)
        
        if 'Contents' not in response:
            continue
        
        for obj in response['Contents']:
            source_key = obj['Key']
            
            data = s3.get_object(Bucket=staging_bucket, Key=source_key)
            body = data['Body'].read()
            
            target_key = source_key
            s3.put_object(
                Bucket=minilake_bucket,
                Key=target_key,
                Body=body
            )
    
    return {'statusCode': 200, 'body': json.dumps('Data refined to minilake')}
