import json
import boto3
import os
from urllib.parse import unquote_plus

s3 = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET_BUCKET']
    
    for record in event['Records']:
        source_bucket = record['s3']['bucket']['name']
        source_key = unquote_plus(record['s3']['object']['key'])
        
        obj = s3.get_object(Bucket=source_bucket, Key=source_key)
        data = obj['Body'].read().decode('utf-8')
        
        target_key = f"case/{source_key.split('/')[-1]}"
        s3.put_object(
            Bucket=staging_bucket,
            Key=target_key,
            Body=data
        )
    
    return {'statusCode': 200, 'body': json.dumps('Case data processed')}
