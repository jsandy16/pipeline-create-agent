import json
import os
import boto3

def handler(event, context):
    s3_client = boto3.client('s3')
    minilake_bucket = os.environ.get('MINILAKE_BUCKET_NAME')
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        print(f'Refining data: s3://{bucket}/{key}')
        
        # Read staging data
        response = s3_client.get_object(Bucket=bucket, Key=key)
        data = response['Body'].read().decode('utf-8')
        
        # Determine target path in minilake
        if 'collision_staging' in key:
            target_key = key.replace('collision_staging/', 'collision/')
        elif 'party_staging' in key:
            target_key = key.replace('party_staging/', 'party/')
        elif 'victim_staging' in key:
            target_key = key.replace('victim_staging/', 'victim/')
        elif 'case_staging' in key:
            target_key = key.replace('case_staging/', 'case/')
        else:
            target_key = key
        
        # Write refined data to minilake
        s3_client.put_object(
            Bucket=minilake_bucket,
            Key=target_key,
            Body=data
        )
    
    return {'statusCode': 200, 'body': 'Data refined and loaded to minilake'}