import json
import os
import boto3

def handler(event, context):
    s3_client = boto3.client('s3')
    staging_bucket = os.environ.get('PARTY_STAGING_BUCKET_NAME')
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        print(f'Processing party data: s3://{bucket}/{key}')
        
        # Read source data
        response = s3_client.get_object(Bucket=bucket, Key=key)
        data = response['Body'].read().decode('utf-8')
        
        # Process and write to staging
        processed_key = key.replace('party_raw/', 'party_staging/')
        s3_client.put_object(
            Bucket=staging_bucket,
            Key=processed_key,
            Body=data
        )
    
    return {'statusCode': 200, 'body': 'Party data processed'}