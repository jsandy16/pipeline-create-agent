import json
import boto3
import os
from urllib.parse import unquote_plus

s3 = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET']
    minilake_bucket = os.environ['MINILAKE_BUCKET']
    
    # Check if all 4 datasets have data
    prefixes = ['collision/', 'party/', 'victim/', 'case/']
    all_available = True
    
    for prefix in prefixes:
        response = s3.list_objects_v2(Bucket=staging_bucket, Prefix=prefix, MaxKeys=1)
        if 'Contents' not in response or len(response['Contents']) == 0:
            all_available = False
            print(f"Missing data in {prefix}")
    
    if not all_available:
        return {
            'statusCode': 200,
            'body': json.dumps('Not all datasets available yet')
        }
    
    # Process and refine all datasets
    for prefix in prefixes:
        response = s3.list_objects_v2(Bucket=staging_bucket, Prefix=prefix)
        
        if 'Contents' in response:
            for obj in response['Contents']:
                source_key = obj['Key']
                
                # Read from staging
                file_response = s3.get_object(Bucket=staging_bucket, Key=source_key)
                data = file_response['Body'].read()
                
                # Write to minilake (refined)
                destination_key = source_key
                s3.put_object(
                    Bucket=minilake_bucket,
                    Key=destination_key,
                    Body=data
                )
                
                print(f"Refined {source_key} to minilake")
    
    return {
        'statusCode': 200,
        'body': json.dumps('All datasets refined and written to minilake')
    }
