import json
import boto3
import os
from urllib.parse import unquote_plus

s3 = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET']
    
    for record in event['Records']:
        source_bucket = record['s3']['bucket']['name']
        source_key = unquote_plus(record['s3']['object']['key'])
        
        # Read source file
        response = s3.get_object(Bucket=source_bucket, Key=source_key)
        data = response['Body'].read()
        
        # Write to staging with victim prefix
        destination_key = f"victim/{source_key.split('/')[-1]}"
        s3.put_object(
            Bucket=staging_bucket,
            Key=destination_key,
            Body=data
        )
        
        print(f"Processed {source_key} to {destination_key}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Victim data processed successfully')
    }
