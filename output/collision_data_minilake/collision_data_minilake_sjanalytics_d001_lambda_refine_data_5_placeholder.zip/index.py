import boto3
import json
import os

s3 = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET_BUCKET']
    minilake_bucket = os.environ['MINILAKE_BUCKET']
    
    # Check if all 4 datasets are available in staging
    prefixes = ['collision/', 'party/', 'victim/', 'case/']
    
    for prefix in prefixes:
        # List objects in each prefix
        response = s3.list_objects_v2(
            Bucket=staging_bucket,
            Prefix=prefix
        )
        
        if 'Contents' not in response or len(response['Contents']) == 0:
            return {
                'statusCode': 200,
                'body': json.dumps(f'Waiting for {prefix} data')
            }
        
        # Process and refine data to minilake
        for obj in response['Contents']:
            source_key = obj['Key']
            if source_key.endswith('/'):
                continue
            
            data_response = s3.get_object(Bucket=staging_bucket, Key=source_key)
            data = data_response['Body'].read()
            
            # Write refined data to minilake
            s3.put_object(
                Bucket=minilake_bucket,
                Key=source_key,
                Body=data
            )
    
    return {
        'statusCode': 200,
        'body': json.dumps('All datasets refined and written to minilake')
    }
