import boto3
import json
import os

s3 = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET_BUCKET']
    
    for record in event['Records']:
        source_bucket = record['s3']['bucket']['name']
        source_key = record['s3']['object']['key']
        
        # Read raw case data
        response = s3.get_object(Bucket=source_bucket, Key=source_key)
        data = response['Body'].read().decode('utf-8')
        
        # Transform and write to staging
        filename = source_key.split('/')[-1]
        staging_key = f"case/{filename}"
        
        s3.put_object(
            Bucket=staging_bucket,
            Key=staging_key,
            Body=data
        )
    
    return {'statusCode': 200, 'body': json.dumps('Case data processed')}
