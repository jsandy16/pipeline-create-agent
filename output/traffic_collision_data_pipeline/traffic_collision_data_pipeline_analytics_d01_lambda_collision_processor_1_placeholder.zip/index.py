import json
import boto3
import os
from urllib.parse import unquote_plus

s3_client = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET_BUCKET']
    
    for record in event['Records']:
        source_bucket = record['s3']['bucket']['name']
        source_key = unquote_plus(record['s3']['object']['key'])
        
        # Copy to staging with collision prefix
        destination_key = f"collision/{source_key.split('/')[-1]}"
        
        s3_client.copy_object(
            CopySource={'Bucket': source_bucket, 'Key': source_key},
            Bucket=staging_bucket,
            Key=destination_key
        )
        
        print(f"Copied {source_key} to staging: {destination_key}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Collision data processed successfully')
    }
