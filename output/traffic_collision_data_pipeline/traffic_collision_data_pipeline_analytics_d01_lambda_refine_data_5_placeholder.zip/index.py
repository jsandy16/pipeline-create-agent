import json
import boto3
import os
from urllib.parse import unquote_plus

s3_client = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET_BUCKET']
    minilake_bucket = os.environ['MINILAKE_BUCKET']
    
    for record in event['Records']:
        source_key = unquote_plus(record['s3']['object']['key'])
        
        # Determine dataset type from prefix
        if source_key.startswith('collision/'):
            dataset_type = 'collision'
        elif source_key.startswith('party/'):
            dataset_type = 'party'
        elif source_key.startswith('victim/'):
            dataset_type = 'victim'
        elif source_key.startswith('case/'):
            dataset_type = 'case'
        else:
            print(f"Unknown prefix for {source_key}")
            continue
        
        # Copy refined data to minilake with same structure
        destination_key = f"{dataset_type}/{source_key.split('/')[-1]}"
        
        s3_client.copy_object(
            CopySource={'Bucket': staging_bucket, 'Key': source_key},
            Bucket=minilake_bucket,
            Key=destination_key
        )
        
        print(f"Refined {source_key} to minilake: {destination_key}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Data refinement completed')
    }
