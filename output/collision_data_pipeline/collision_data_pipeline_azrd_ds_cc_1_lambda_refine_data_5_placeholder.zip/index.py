import json
import boto3
import os

s3 = boto3.client('s3')

def handler(event, context):
    staging_bucket = os.environ['STAGING_BUCKET']
    target_bucket = os.environ['MINILAKE_BUCKET']
    
    # Check if all 4 datasets are available
    prefixes = ['collision/', 'party/', 'victim/', 'case/']
    available = {}
    
    for prefix in prefixes:
        response = s3.list_objects_v2(Bucket=staging_bucket, Prefix=prefix, MaxKeys=1)
        available[prefix] = 'Contents' in response
    
    if not all(available.values()):
        return {'statusCode': 202, 'message': 'Waiting for all datasets'}
    
    # Refine and copy all datasets to minilake
    for prefix in prefixes:
        dataset_name = prefix.rstrip('/')
        response = s3.list_objects_v2(Bucket=staging_bucket, Prefix=prefix)
        
        if 'Contents' not in response:
            continue
        
        for obj in response['Contents']:
            source_key = obj['Key']
            target_key = source_key
            
            # Copy from staging to minilake
            s3.copy_object(
                CopySource={'Bucket': staging_bucket, 'Key': source_key},
                Bucket=target_bucket,
                Key=target_key
            )
    
    return {'statusCode': 200, 'message': 'All datasets refined and copied to minilake'}
