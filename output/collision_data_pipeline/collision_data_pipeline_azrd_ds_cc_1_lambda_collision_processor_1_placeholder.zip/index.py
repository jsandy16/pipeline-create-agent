import json
import boto3
import os

s3 = boto3.client('s3')

def handler(event, context):
    # Get source bucket and key from S3 event
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    source_key = event['Records'][0]['s3']['object']['key']
    
    # Get target bucket from environment
    target_bucket = os.environ['STAGING_BUCKET']
    
    # Read raw data
    response = s3.get_object(Bucket=source_bucket, Key=source_key)
    raw_data = response['Body'].read().decode('utf-8')
    
    # Process collision data
    lines = raw_data.strip().split('\n')
    processed_data = []
    for line in lines:
        # Basic transformation/validation
        processed_data.append(line.strip())
    
    # Write to staging
    target_key = f"collision/{source_key.split('/')[-1]}"
    s3.put_object(
        Bucket=target_bucket,
        Key=target_key,
        Body='\n'.join(processed_data)
    )
    
    return {'statusCode': 200, 'message': 'Collision data processed'}
