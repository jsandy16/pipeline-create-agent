import json
import boto3
import os

s3 = boto3.client('s3')

def handler(event, context):
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    source_key = event['Records'][0]['s3']['object']['key']
    target_bucket = os.environ['STAGING_BUCKET']
    
    response = s3.get_object(Bucket=source_bucket, Key=source_key)
    raw_data = response['Body'].read().decode('utf-8')
    
    lines = raw_data.strip().split('\n')
    processed_data = []
    for line in lines:
        processed_data.append(line.strip())
    
    target_key = f"case/{source_key.split('/')[-1]}"
    s3.put_object(
        Bucket=target_bucket,
        Key=target_key,
        Body='\n'.join(processed_data)
    )
    
    return {'statusCode': 200, 'message': 'Case data processed'}
